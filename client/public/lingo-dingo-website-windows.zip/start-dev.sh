#!/bin/bash
echo "Starting Lingo Dingo development server..."
echo
export NODE_ENV=development
npx tsx server/index.ts